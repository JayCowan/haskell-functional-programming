module Main where

import Ex04

main = putStrLn declaration
